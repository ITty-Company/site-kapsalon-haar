# STORY — «Een lok krijgt een nieuwe kleur»
Eén lok haar op een handdoek aan de kleurbar → de kom vult zich met koperkleur → folie, lok half geverfd → folie dicht, inwerken (stoom) → (zoom-whip) spoelen in de wasbak → (diagonale kopershutter) droog, glanzend koper met föhn → portal: lege petrol stoel in avondlicht «jouw stoel staat klaar».
Kaders K1–K7 (Higgsfield gpt_image_2_6, K2/K3/K4/K5/K6/K7 met K1 als referentie; K2 en K4 opnieuw voor continuïteit). Clips LTX: f1 k1→k2, f2 k2→k3, f3 k3→k4, f5 k5-loop, f6 k6-loop; whip en wipe in code (ffmpeg xfade). Geen mensen, geen handen.
Over ons: straat (O1) → etalage in de avond (O2), LTX «of». Afspraak: A1-loop. Contact: O2-loop.
